# 第1段階：画面配置とWebView標準機能

対象ベース: fa14d4b73e389f63eaa45d698cf8931ce03043e2（添付ZIP）。
このパッケージは修正候補ソースです。APKではありません。
作成環境にGradle・Android SDKがなく、コンパイル・JUnit・実機試験は未実施です。
導入前にGitHub Actionsで `gradle testDebugUnitTest assembleDebug` を実行してください。

## コードを読んで確認したこと

| 項目 | 元の実装で確認できた内容 |
|---|---|
| UI | URL行64dp。下の棚は区切り3dp、タブ66dp、線、ナビ48dp。上下の独自バーはシステムInsetsを明示的に処理していない |
| 全画面 | WebChromeClientは進捗とタイトル更新のみ。onShowCustomView/onHideCustomViewなし |
| 画像選択 | onShowFileChooserなし。Google Lensのアプリ誘導とは別の問題 |
| 外部URL | shouldOverrideUrlLoadingなし。intentスキーム処理なし |
| 長押し | setOnLongClickListenerなし |
| キー | Activityでショートカット処理なし |
| 広告 | 標準6ドメイン・強11ドメイン。主文書は遮断せず、DOM非表示やService Worker対応なし |
| X | JavaScript、DOM storage、第三者Cookieはすでに有効。ページ全体を覆う透明なComposeジェスチャー層はこのコードにはない。前回答の原因推測は未確認 |
| タブ | SleipnirTabShelfという名前だが、実体は一列の横スクロール。グループのデータ構造はない |

## 第1段階の構成

| 領域 | 内容・寸法 |
|---|---|
| 上端 | ステータスバー用の空白。操作ボタンなし |
| URL行 | 64dpの上部URL行を維持。元のボタン位置は空白。時計との重なりを避けるため行のY座標だけ安全領域の下へ移す |
| 左側 | 幅56dp、戻る・進む・更新/停止・ホーム。縦スクロール可 |
| 中央 | 選択中のWebViewを一つだけ表示。ページ全面を覆うジェスチャー層は追加しない |
| 右側 | 幅56dp、新規タブ・タブ一覧・盾・メニュー。縦スクロール可 |
| 下部 | 元の棚相当の118dpを空白で維持。OSの下部Insetsが大きければその値を使う。ボタン・タブは置かない |
| 全画面中 | 動画用Viewを最上位に表示。通常操作部を覆う。終了すると元のシステムバー表示状態へ戻す |

URLの絶対座標の完全維持とステータスバーへの非重複は元画面では両立しないため、安全領域の分だけ下げています。
下部の空白を縮めてページを広げる変更は行っていません。

## 変更したファイル

1. app/src/main/java/com/example/privatebrowser/BrowserActivity.kt
   左右配置、一覧ダイアログ、キーボード処理、履歴状態更新、共通コールバック接続。
2. app/src/main/java/com/example/privatebrowser/BrowserPlatform.kt（追加）
   リンク長押し、全画面、システムファイル選択、intentフォールバック。
3. app/src/test/java/com/example/privatebrowser/BrowserPlatformTest.kt（追加）
   HTTPSフォールバックの入力判定テスト8件。テストコード追加のみ、未実行。

既存のプロフィール、Cookie分離、CI、依存関係、広告リストには変更なし。
旧タブ棚関数は比較用に残っているが、新画面からは呼ばない。

## 操作

| 操作 | キー |
|---|---|
| 新規タブ | Ctrl+T |
| 閉じる | Ctrl+W |
| 次/前のタブ | Ctrl+Tab / Ctrl+Shift+Tab |
| 履歴を戻る/進む | Alt+左 / Alt+右 |
| URL欄 | Ctrl+L |
| 更新 | Ctrl+R / F5 |
| 全画面終了 | 戻る / Esc |

Ctrl+Z/Yはページ履歴に割り当てず、文字入力のUndo/Redoを妨げない。
リンク長押しは新規タブ、背景タブ、コピー、共有。リンク付き画像では画像URLをリンク先と誤認しないようrequestFocusNodeHrefを使用。
画像だけの長押し保存・マウス専用サイドボタンはこの段階では未実装。

## 外部アプリと画像検索

通常HTTP(S)はWebViewへ任せる。intent URLは外部起動せず、parseUriで取得したHTTPSのbrowser_fallback_urlだけを開く。
フォールバックを二重デコードしない。HTTPは元アプリのcleartext禁止方針に合わせてフォールバックとして許可しない。
フォールバックがない場合は元のページを維持して通知する。短時間の繰り返しは3回で停止。
これでGoogle LensのWebアップロード画面が必ず提供されるとは限らない。サイト側が再びアプリへ誘導するケースは別途実機確認が必要。
通常のinput type=fileにはシステムピッカーを接続。キャンセルとActivity終了でcallbackを解放。
撮影・カメラ権限・任意のWeb権限の自動許可は追加しない。
元のallowFileAccess=false/allowContentAccess=falseを維持。選択したcontent URIを返す経路が実機でアップロード完了するか確認する。

## まだ直したと主張しない項目

- ニコ動の黒画面、ニコ生タイムシフト。まず同じURLを同じ端末の別ブラウザで比較。スマートフォン/PC表示の差も記録。
- Fantia購入履歴の音声のみ。同一動画・同じ画質を通常入口と比較。動画サイズを原因と断定しない。映像トラック、HTTP状態、プレイヤー要素の寸法等を調べる。
- Xログイン。背景が灰色という画像だけではDOMモーダル/JS読込失敗/認証側制限の切り分け不可。今回の全画面・アップロード追加をログイン修正と扱わない。
- 広告の網羅的遮断と強制ページ遷移防止。今回は自動window.open許可をfalseにしただけ。これを広告リダイレクト対策の完成と扱わない。
- Sleipnir風のグループ列。今回の一覧は暫定の縦一覧。グループ列UI、グループ追加/移動/閉じる、永続化は別段階。
- タブ多数時のメモリ上限、プロセス終了/回転後のセッション復元。元コードの制限が残る。

## 次段階の仕様案

グループ列は「一覧画面の1列が1グループ、その中にタブが縦に並ぶ」案。
groupIdとtabIdは不変IDにし、配列インデックスをIDにしない。通常ページ上の上下左右スワイプを横取りしない。
ユーザーの意図するSleipnirの配置と一致するか、参考画像と比較してから実装する。
広告ブロックは既知ホスト判定・主文書ナビゲーション判定・ポップアップ判定を分離し、遮断理由/ヒット数を可視化する。
第三者通信の一括遮断やhasGesture=falseの一律遮断はログイン・決済・動画を壊すため採用しない。
通信診断時はCookie、Authorization、URLのクエリ、署名付き動画URLをログへ保存しない。

## 導入

最新の作業ブランチに追加修正がない場合、上記3ファイルを同じ相対パスへ配置してコミット。
mainの初期コードにこのBrowserActivity.ktだけを置かないこと。AdBlocker.kt/AppTheme.kt等を含む対象ブランチが必要。
新しい修正が既にある場合は丸ごと上書きせず差分を比較する。
このZIPは全ソース同梱なので、別ブランチでビルド用の素材としても使用可能。
READMEの既存説明と異なる点は本書を優先する。

## Codexへ渡す短い指示

対象は添付元コミットfa14d4b73e389f63eaa45d698cf8931ce03043e2の実装です。
修正済みBrowserActivity.kt、BrowserPlatform.kt、BrowserPlatformTest.ktをレビューし、現在ブランチとの差分として適用してください。
UIや未実装機能を勝手に再設計せず、docs/REPAIR_PHASE1.mdを仕様としてください。
gradle testDebugUnitTest assembleDebugで検証し、失敗時はその原因を修正してください。
APKにはビルド対象コミットを併記してください。実機未確認のサイトを解決済みと報告しないでください。

## 実機チェック（ビルド後）

1. Galaxyのタスクバー表示/非表示、横/縦画面で左右ボタンが押せる。URLが時計と重ならない。
2. 一般HTTPSページのリンク/リンク付き画像を長押しし、新規タブ・背景タブ・コピーを確認。
3. Ctrl+T/W/Tab、Alt+左右をWebページとURL入力中に試す。Ctrl+Zで文字入力の取消ができる。
4. 通常動画を全画面→戻る→再度全画面。黒い覆いが残らず、タブ操作が復帰する。
5. input type=fileで写真選択→アップロード完了、キャンセル→再選択を確認。
6. Googleの画像検索でGoogleアプリが勝手に開かず、intentエラーページへ移らない。Web側が利用不可ならその状態を記録。
7. タブ切替でページが再読込されない。最後のタブを閉じてもクラッシュしない。
8. ニコ動/Fantia/Xは「改善/変化なし/悪化」を個別記録。ログイン情報や署名付きURLを公開しない。

参考: Android公式 WebChromeClient / WebViewClient / Compose WindowInsets API。
https://developer.android.com/reference/android/webkit/WebChromeClient
https://developer.android.com/reference/android/webkit/WebViewClient
https://developer.android.com/develop/ui/compose/system/insets
